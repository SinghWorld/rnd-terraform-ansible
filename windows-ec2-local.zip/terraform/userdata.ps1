<powershell>
# =============================================================
# userdata.ps1
# Runs once at first boot as SYSTEM via EC2Launch v2
#
# What this does:
#   1. Sets execution policy
#   2. Creates a local admin user for Ansible (ansible_admin)
#   3. Fully configures WinRM — HTTP on port 5985
#   4. Opens Windows Firewall rules
#   5. Writes a boot log to C:\winrm_setup.log
# =============================================================

$LogFile = "C:\winrm_setup.log"

function Write-Log {
    param([string]$Message)
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    "$timestamp  $Message" | Tee-Object -FilePath $LogFile -Append
}

Write-Log "=== WinRM Bootstrap Started ==="

# -------------------------------------------------------------
# STEP 1 — Execution policy
# -------------------------------------------------------------
Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Scope LocalMachine -Force
Write-Log "ExecutionPolicy set to Unrestricted"

# -------------------------------------------------------------
# STEP 2 — Create local admin account for Ansible
#           NOTE: Change the password below to match your
#           TF_VAR_winrm_password value
# -------------------------------------------------------------
$AnsibleUser = "ansible_admin"
$AnsiblePass = ConvertTo-SecureString "REPLACE_WITH_YOUR_PASSWORD" -AsPlainText -Force

# Remove user if it already exists (idempotent)
if (Get-LocalUser -Name $AnsibleUser -ErrorAction SilentlyContinue) {
    Remove-LocalUser -Name $AnsibleUser
    Write-Log "Removed existing user: $AnsibleUser"
}

New-LocalUser `
    -Name        $AnsibleUser `
    -Password    $AnsiblePass `
    -FullName    "Ansible Admin" `
    -Description "Local admin used by Ansible WinRM" `
    -PasswordNeverExpires

Add-LocalGroupMember -Group "Administrators" -Member $AnsibleUser
Write-Log "Created local admin user: $AnsibleUser"

# -------------------------------------------------------------
# STEP 3 — Stop WinRM, reset all config cleanly
# -------------------------------------------------------------
Write-Log "Stopping WinRM service..."
Stop-Service -Name WinRM -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2

# Remove ALL existing listeners so we start clean
Write-Log "Removing existing WinRM listeners..."
Get-ChildItem WSMan:\Localhost\listener | Remove-Item -Recurse -ErrorAction SilentlyContinue

# -------------------------------------------------------------
# STEP 4 — Enable PSRemoting (creates default HTTP listener)
# -------------------------------------------------------------
Write-Log "Enabling PSRemoting..."
Enable-PSRemoting -Force -SkipNetworkProfileCheck
Start-Sleep -Seconds 2

# -------------------------------------------------------------
# STEP 5 — Tune WinRM service settings
# -------------------------------------------------------------
Write-Log "Configuring WinRM service settings..."

# Allow unencrypted (required for HTTP basic auth from Linux Ansible)
Set-Item -Path WSMan:\localhost\Service\AllowUnencrypted    -Value $true
Set-Item -Path WSMan:\localhost\Service\Auth\Basic          -Value $true
Set-Item -Path WSMan:\localhost\Service\Auth\CredSSP        -Value $true

# Increase timeouts and memory limits
Set-Item -Path WSMan:\localhost\MaxTimeoutms                -Value 1800000
Set-Item -Path WSMan:\localhost\Shell\MaxMemoryPerShellMB   -Value 1024

# Allow remote shell access
Set-Item -Path WSMan:\localhost\Shell\AllowRemoteShellAccess -Value $true

Write-Log "WinRM service settings configured"

# -------------------------------------------------------------
# STEP 6 — Ensure HTTP listener exists on port 5985
# -------------------------------------------------------------
Write-Log "Creating WinRM HTTP listener on port 5985..."
$listenerExists = Get-WSManInstance `
    -ResourceURI winrm/config/listener `
    -SelectorSet @{Address="*"; Transport="HTTP"} `
    -ErrorAction SilentlyContinue

if (-not $listenerExists) {
    New-WSManInstance `
        -ResourceURI winrm/config/listener `
        -SelectorSet  @{Address="*"; Transport="HTTP"} `
        -ValueSet     @{Port="5985"; Enabled="true"}
    Write-Log "HTTP listener created"
} else {
    Write-Log "HTTP listener already exists"
}

# -------------------------------------------------------------
# STEP 7 — Windows Firewall rules
# -------------------------------------------------------------
Write-Log "Configuring Windows Firewall..."

# Remove any conflicting rules first
Remove-NetFirewallRule -DisplayName "WinRM HTTP"  -ErrorAction SilentlyContinue
Remove-NetFirewallRule -DisplayName "WinRM HTTPS" -ErrorAction SilentlyContinue

New-NetFirewallRule `
    -DisplayName "WinRM HTTP" `
    -Direction   Inbound `
    -Protocol    TCP `
    -LocalPort   5985 `
    -Action      Allow `
    -Profile     Any

New-NetFirewallRule `
    -DisplayName "WinRM HTTPS" `
    -Direction   Inbound `
    -Protocol    TCP `
    -LocalPort   5986 `
    -Action      Allow `
    -Profile     Any

Write-Log "Firewall rules created"

# -------------------------------------------------------------
# STEP 8 — Start WinRM and set to automatic
# -------------------------------------------------------------
Set-Service -Name WinRM -StartupType Automatic
Start-Service -Name WinRM
Start-Sleep -Seconds 3

$svc = Get-Service -Name WinRM
Write-Log "WinRM service status: $($svc.Status)"

# -------------------------------------------------------------
# STEP 9 — Verify listener is active
# -------------------------------------------------------------
Write-Log "Active WinRM listeners:"
Get-WSManInstance -ResourceURI winrm/config/listener -Enumerate | ForEach-Object {
    Write-Log "  Transport=$($_.Transport)  Port=$($_.Port)  Enabled=$($_.Enabled)"
}

# Quick self-test
try {
    $result = Invoke-Command -ComputerName localhost -ScriptBlock { "WinRM self-test OK" } -ErrorAction Stop
    Write-Log "Self-test: $result"
} catch {
    Write-Log "Self-test FAILED: $_"
}

# -------------------------------------------------------------
# STEP 10 — Disable Windows Firewall for ALL profiles
#            (belt-and-braces for testing; re-enable for prod)
# -------------------------------------------------------------
Write-Log "Disabling Windows Firewall (testing mode)..."
Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False

Write-Log "=== WinRM Bootstrap Complete ==="
Write-Log "Port 5985 should now be open and accepting connections."
Write-Log ""
Write-Log "Test from Linux with:"
Write-Log "  curl -s http://<PUBLIC_IP>:5985/wsman"
</powershell>
<persist>true</persist>
